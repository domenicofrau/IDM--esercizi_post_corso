package pratici.esercizio02;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Benzinaio {

	static double prezzoBenzina = 1.99;
	static double prezzoDiesel = 0.99;

	static class Pompa {

		private String tipoCarburante;
		private double serbatoioBenzina = 1000;
		private double serbatoioDiesel = 1000;
		private double incassoBenzina = 0;
		private double incassoDiesel = 0;
		private double saldo = 0;
		private double litriErogabili = 0;
		private int tempoProssimaDisponibilita = 0;

		public void accettaBanconota(int banconota) {
			if (banconota == 5 || banconota == 10 || banconota == 20 || banconota == 50 || banconota == 100) {
				saldo += banconota;
			} else {
				System.out.println("ATTENZIONE - La banconota inserita non può essere accettata.");
			}
		}

		public void selezionaCarburante(String tipoCarburante) {
			this.tipoCarburante = tipoCarburante;

			if (tipoCarburante.equalsIgnoreCase("benzina") || tipoCarburante.equalsIgnoreCase("b")) {
				litriErogabili = saldo / prezzoBenzina;
				if (litriErogabili < serbatoioBenzina) {
					confermaRifornimento(tipoCarburante);
				} else {
					double benzinaADisposizione = serbatoioBenzina * prezzoBenzina;
					System.out.println("E' possibile rifornire un massimo di " + benzinaADisposizione + " €");
					stampaScontrino();
				}
			}

			if (tipoCarburante.equalsIgnoreCase("diesel") || tipoCarburante.equalsIgnoreCase("d")) {
				litriErogabili = saldo / prezzoDiesel;
				if (litriErogabili < serbatoioDiesel) {
					confermaRifornimento(tipoCarburante);
				} else {
					double dieselADisposizione = serbatoioBenzina * prezzoBenzina;
					stampaScontrino();
					System.out.println("E' possibile rifornire un massimo di " + dieselADisposizione + " €");
				}
			}
		}

		public void confermaRifornimento(String tipoCarburante) {
			System.out
			.println("\n" + "*******************************************************************************");
			System.out.println("Verranno erogati: " + litriErogabili + " litri di " + tipoCarburante);
			System.out.println("\nProcedere con il rifornimento? Y/N");
			Scanner scanner = new Scanner(System.in);
			String input = scanner.nextLine();

			if (input.equalsIgnoreCase("y")) {
				if (tipoCarburante.equalsIgnoreCase("benzina") || tipoCarburante.equalsIgnoreCase("b")) {
					serbatoioBenzina = serbatoioBenzina - litriErogabili;
					incassoBenzina += saldo;
					saldo = 0;
					System.out
					.println("\n" + "*******************************************************************************");
					System.out.println("Rifornimento completato!");
				}
				if (tipoCarburante.equalsIgnoreCase("diesel") || tipoCarburante.equalsIgnoreCase("d")) {
					serbatoioDiesel = serbatoioDiesel - litriErogabili;
					incassoDiesel += saldo;
					saldo = 0;
					System.out
					.println("\n" + "*******************************************************************************");
					System.out.println("Rifornimento completato!");
				}
			}

			if (input.equalsIgnoreCase("n")) {
				System.out.println("Rifornimento annullato!");
			}

			if (!input.equalsIgnoreCase("y") & !input.equalsIgnoreCase("n")) {
				System.out.println("Digitare Y per confermare o N per annullare l'operazione");
				confermaRifornimento(tipoCarburante);
			}
		}

		public void stampaScontrino() {
			System.out.println("Carburante non sufficiente nel serbatoio per effettuare il rifornimento!");
			System.out.println("Rimangono nel serbatoio: " + serbatoioBenzina + " litri di benzina e " + serbatoioDiesel
					+ " litri di diesel");

		}

		public double calcolaIncassoPompa() {
			return incassoBenzina + incassoDiesel;
		}

		public void ricaricaSerbatoio(String tipoCarburante, double litri) {
			if (tipoCarburante.equalsIgnoreCase("Benzina")) {
				serbatoioBenzina += litri;
			} else if (tipoCarburante.equalsIgnoreCase("Diesel")) {
				serbatoioDiesel += litri;
			} else {
				System.out.println("Tipo di carburante non valido.");
			}
		}

		public void visualizzaGiacenza() {
			System.out.println("Giacenza in serbatoio: Benzina - " + serbatoioBenzina + " litri, Diesel - "
					+ serbatoioDiesel + " litri.");
		}

		public double getSerbatoioBenzina() {
			return serbatoioBenzina;
		}

		public double getSerbatoioDiesel() {
			return serbatoioDiesel;
		}

		public void decrementaSerbatoioDiesel(double litri) {
			this.serbatoioDiesel -= litri;
		}

		public void incrementaIncassoDiesel(double importo) {
			this.incassoDiesel += importo;
		}

		public void decrementaSerbatoioBenzina(double litri) {
			this.serbatoioBenzina -= litri;
		}

		public void incrementaIncassoBenzina(double importo) {
			this.incassoBenzina += importo;
		}

		public int getTempoProssimaDisponibilita() {
			return tempoProssimaDisponibilita;
		}

		public void decrementaSerbatoio(String tipoCarburante, double litriRichiesti) {
			if (tipoCarburante.equalsIgnoreCase("D")) {
				serbatoioDiesel -= litriRichiesti;
			} else {
				serbatoioBenzina -= litriRichiesti;
			}
		}

		public void incrementaIncasso(double importo, String tipoCarburante) {
			if (tipoCarburante.equalsIgnoreCase("B")) {
				incassoBenzina += importo;
			} else if (tipoCarburante.equalsIgnoreCase("D")) {
				incassoDiesel += importo;
			} else {
				System.out.println("Tipo di carburante non valido.");
			}
		}

		public void aggiornaTempoProssimaDisponibilita(int tempo) {
			tempoProssimaDisponibilita = tempo;
		}

	}

	static class Cliente {
		String id;
		String tipoCarburante;
		double importo;
		int tempoArrivo;
		int pompaAssegnata;

		public Cliente(double importo, String tipoCarburante, int tempoArrivo) {
			super();
			this.importo = importo;
			this.tipoCarburante = tipoCarburante;
			this.tempoArrivo = tempoArrivo;
			this.pompaAssegnata = -1;
		}

		public double getImporto() {
			return importo;
		}

		public void setImporto(double importo) {
			this.importo = importo;
		}

		public String getTipoCarburante() {
			return tipoCarburante;
		}

		public void setTipoCarburante(String tipoCarburante) {
			this.tipoCarburante = tipoCarburante;
		}

		public int getTempoArrivo() {
			return tempoArrivo;
		}

		public void setTempoArrivo(int tempoArrivo) {
			this.tempoArrivo = tempoArrivo;
		}

		public int getPompaAssegnata() {
			return pompaAssegnata;
		}

		public void setPompaAssegnata(int pompaAssegnata) {
			this.pompaAssegnata = pompaAssegnata;
		}

		@Override
		public String toString() {
			return "Cliente [" + id + "]";
		}

	}
	
	public static double calcolaIncassoTotale(Pompa[] pompe) {
		double incassoTotale = 0;
		for (Pompa pompa : pompe) {
			incassoTotale += pompa.calcolaIncassoPompa();
		}
		System.out.println("L'incasso totale di tutte le pompe è di: " + incassoTotale + " €");
		return incassoTotale;
	}

	private static List<Cliente> leggiClientiDaFile(String percorsoFile) {
		List<Cliente> clienti = new ArrayList<>();
		File file = new File(percorsoFile);

		try {
			Scanner scanner = new Scanner(file);
			while (scanner.hasNextLine()) {
				String riga = scanner.nextLine();
				String[] parti = riga.split(" ");

				double importo = Double.parseDouble(parti[0].trim());
				String tipoCarburante = parti[1].trim();
				int tempoArrivo = Integer.parseInt(parti[2].trim());

				Cliente cliente = new Cliente(importo, tipoCarburante, tempoArrivo);
				clienti.add(cliente);
			}
			scanner.close();
		} catch (FileNotFoundException e) {
			System.out.println("File non trovato: " + percorsoFile);
		} catch (NumberFormatException e) {
			System.out.println("Errore nella conversione del numero: " + e.getMessage());
		}

		return clienti;
	}


//	   __  __          _____ _   _ 
//	  |  \/  |   /\   |_   _| \ | |
//	  | \  / |  /  \    | | |  \| |
//	  | |\/| | / /\ \   | | | . ` |
//	  | |  | |/ ____ \ _| |_| |\  |
//	  |_|  |_/_/    \_\_____|_| \_|

	public static void main(String[] args) {

		Pompa[] pompe = new Pompa[4];
		for (int i = 0; i < pompe.length; i++) {
			pompe[i] = new Pompa();
		}

		Scanner scanner = new Scanner(System.in);
		boolean backToMain = false;

		while (!backToMain) {
			System.out
					.println("\n" + "*******************************************************************************");
			System.out.println("Opzioni:" + "\n"
					+ "\n1. Rifornimento \n2. Rifornimento Automatizzato \n3. Ricarica serbatoio \n4. Visualizza giacenza \n5. Visualizza incasso \n6. Esci");
			String programma = scanner.nextLine();

			switch (programma) {
			case "1":
				while (true) {
					System.out.println(
							"\n" + "*******************************************************************************");
					System.out.println("Inserisci una banconota (5, 10, 20, 50, 100) o digita 'exit' per uscire:");
					String inputBanconota = scanner.nextLine();

					if (inputBanconota.equals("exit")) {
						System.out.println("Programma terminato.");
						backToMain = false;
						break;
					}

					int banconota = Integer.parseInt(inputBanconota);

					System.out.println(
							"\n" + "*******************************************************************************");
					System.out
							.println("Selezionare la pompa con cui rifornire (1, 2, 3, 4) o digita 'exit' per uscire:");
					String inputPompa = scanner.nextLine();
					int numeroPompa = Integer.parseInt(inputPompa);

					if (inputPompa.equals("exit")) {
						System.out.println("Programma terminato.");
						backToMain = false;
						break;
					}

					if (numeroPompa >= 1 && numeroPompa <= 4) {
						pompe[numeroPompa - 1].accettaBanconota(banconota);

						System.out.println("\n"
								+ "*******************************************************************************");
						System.out.println(
								"Seleziona il tipo di carburante (Benzina/Diesel) o digita 'exit' per uscire:");
						String inputCarburante = scanner.nextLine();

						if (inputCarburante.equals("exit")) {
							System.out.println("Programma terminato.");
							backToMain = false;
							break;
						}

						pompe[numeroPompa - 1].selezionaCarburante(inputCarburante);

					} else {
						System.out.println("Pompa non valida. Seleziona una pompa da 1 a 4.");
					}
				}
				break;
				
			case "2":
				System.out.println("\n*******************************************************************************");
				System.out.println("Programma di rifornimento self avviato");
				System.out.println("L'elenco dei clienti è consultabile tramite il file: clienti.txt \n");
				List<Cliente> clienti = leggiClientiDaFile("C:/Users/domen/Desktop/clienti.txt");

				for (Cliente cliente : clienti) {
					double litriRichiesti = cliente.importo
							/ (cliente.tipoCarburante.equalsIgnoreCase("D") ? prezzoDiesel : prezzoBenzina);
					int tempoErogazione = (int) Math.ceil(litriRichiesti / 10);
					boolean pompaAssegnata = false;

					int tempoMinimoDiAttesa = Integer.MAX_VALUE;
					int pompaScelta = -1;

					for (int i = 0; i < pompe.length; i++) {
						Pompa pompa = pompe[i];
						double serbatoioDisponibile = cliente.tipoCarburante.equals("D") ? pompa.getSerbatoioDiesel()
								: pompa.getSerbatoioBenzina();
						int tempoDiAttesa = pompa.getTempoProssimaDisponibilita() - cliente.tempoArrivo;

						if (serbatoioDisponibile >= litriRichiesti && tempoDiAttesa < tempoMinimoDiAttesa) {
							tempoMinimoDiAttesa = tempoDiAttesa;
							pompaScelta = i;
							pompaAssegnata = true;
						}
					}

					if (pompaAssegnata) {
						cliente.pompaAssegnata = pompaScelta + 1;
						Pompa pompa = pompe[pompaScelta];
						pompa.decrementaSerbatoio(cliente.tipoCarburante, litriRichiesti);
						pompa.incrementaIncasso(cliente.importo, cliente.tipoCarburante);
						pompa.aggiornaTempoProssimaDisponibilita(cliente.tempoArrivo + tempoErogazione);
					} else {
						cliente.pompaAssegnata = 0;
					}
				}

				for (Cliente cliente : clienti) {
					System.out.println("Pompa assegnata: " + cliente.pompaAssegnata);
				}
				break;
				
			case "3":
				System.out.println(
						"\n" + "*******************************************************************************");
				System.out.println(
						"Selezionare la pompa che si vuole ricaricare (1, 2, 3, 4) o digita 'exit' per uscire:");
				String inputNumeroPompaRicarica = scanner.nextLine();

				if (inputNumeroPompaRicarica.equals("exit")) {
					System.out.println("Programma terminato.");
					backToMain = false;
					break;
				}

				int numeroPompaRicarica = Integer.parseInt(inputNumeroPompaRicarica);

				if (numeroPompaRicarica < 1 || numeroPompaRicarica > 4) {
					System.out.println("Pompa non valida. Seleziona una pompa da 1 a 4.");
					break;
				}

				System.out.println(
						"\n" + "*******************************************************************************");
				System.out.println(
						"Selezionare il tipo di carburante da ricaricare (Benzina/Diesel) o digita 'exit' per uscire:");
				String tipoCarburante = scanner.nextLine();

				if (tipoCarburante.equals("exit")) {
					System.out.println("Programma terminato.");
					backToMain = false;
					break;
				}

				if (!tipoCarburante.equalsIgnoreCase("Benzina") && !tipoCarburante.equalsIgnoreCase("Diesel")) {
					System.out.println("Tipo di carburante non valido. Scegliere tra Benzina e Diesel.");
					break;
				}

				System.out.println(
						"\n" + "*******************************************************************************");
				System.out.println(
						"Inserire la quantità di carburante da aggiungere in litri o digita 'exit' per uscire:");
				String inputLitriDaAggiungere = scanner.nextLine();

				if (inputLitriDaAggiungere.equals("exit")) {
					System.out.println("Programma terminato.");
					backToMain = false;
					break;
				}

				double litriDaAggiungere = Double.parseDouble(inputLitriDaAggiungere);

				pompe[numeroPompaRicarica - 1].ricaricaSerbatoio(tipoCarburante, litriDaAggiungere);
				System.out.println("Aggiunti " + litriDaAggiungere + " litri di " + tipoCarburante + " alla pompa "
						+ numeroPompaRicarica);
				pompe[numeroPompaRicarica - 1].visualizzaGiacenza();
				System.out.println("Programma terminato.");
				break;

			case "4":
				System.out.println(
						"\n" + "*******************************************************************************");
				System.out.println("Visualizzazione giacenza nei serbatoi di ogni pompa:");
				for (int i = 0; i < pompe.length; i++) {
					System.out.println("Pompa " + (i + 1) + ":");
					pompe[i].visualizzaGiacenza();
				}
				break;

			case "5":
				System.out.println(
						"\n" + "*******************************************************************************");
				System.out.println("Visualizzazione incasso di ogni pompa e totale:" + "\n");
				double incassoTotale = 0;
				for (int i = 0; i < pompe.length; i++) {
					double incassoPompa = pompe[i].calcolaIncassoPompa();
					System.out.println("Incasso della Pompa " + (i + 1) + ": " + incassoPompa + " €");
					incassoTotale += incassoPompa;
				}

				System.out.println("\n" + "Incasso totale di tutte le pompe: " + incassoTotale + " €");
				break;

			case "6":
				System.out.println(
						"\n" + "*******************************************************************************");
				System.out.println("Programma chiuso.");
				System.exit(0);
			}
		}
		scanner.close();
		System.out.println("Programma terminato.");
	}
}
