package esercizio1;

public interface ITest {

//  METODI DA IMPLEMENTARE IN UNA CLASSE CHE IMPLEMENTA ITest

	void saveString(String tmp);

	boolean isLastStringEmpty();

	int countUnique();

}

