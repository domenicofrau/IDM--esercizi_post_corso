package esercizio1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ITestImpl implements ITest{

	private List<String> listaStringhe = new ArrayList<>();
	
	@Override
	public void saveString(String tmp) {
		listaStringhe.add(tmp);
		
	}

	@Override
	public boolean isLastStringEmpty() {
		
		return listaStringhe.isEmpty() || listaStringhe.get(listaStringhe.size()-1).length() == 0;
	}

	@Override
	public int countUnique() {
		Set<String> set = new HashSet<>(listaStringhe);
		return set.size();
	}
	
	

}
