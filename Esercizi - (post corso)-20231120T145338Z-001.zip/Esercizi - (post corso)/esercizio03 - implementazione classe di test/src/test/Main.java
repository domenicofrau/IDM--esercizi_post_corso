package test;

import java.util.Scanner;

import esercizio1.ITest;
import esercizio1.ITestImpl;


public class Main {

   
    public static void main(String[] args) {
    

        ITest test = new ITestImpl();
        
        Scanner scanner = new Scanner(System.in);

        while (true) {
            // Leggi e memorizza la stringa in input
            String tmp = scanner.nextLine();
            test.saveString(tmp);
            
            
            // Se l'ultima stringa inserita è vuota
            if (test.isLastStringEmpty()) {

                // Mostra il numero di stringhe univoche inserite, ed esci
                int tot = test.countUnique();
         
                System.out.println("Stringhe univoche inserite: " + (tot-1));
                break;
            }
        }
        
        scanner.close();
    }   
}