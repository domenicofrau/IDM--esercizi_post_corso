package esercizio1;

import java.util.Arrays;
import java.util.List;

public enum TipoFile {

	DOCUMENTS("Documents", Arrays.asList("doc", "txt")),
	IMAGE("Image", Arrays.asList("jpg", "jpeg")),
	VIDEO("Video", Arrays.asList("avi", "mpg")),
	OTHER("Other", Arrays.asList("all", "all"));
	
	private String name;
	private List<String> extention;
	
	TipoFile(String name, List<String> extention) {
		this.name = name;
        this.extention = extention;
	}

	protected String getName() {
		return name;
	}

	protected List<String> getExtention() {
		return extention;
	}
	
}
