package esercizio1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Esercizio1Main {

	public static void main(String[] args) {
		Esercizio1Main.writer();

	}

	private static FileMap mapping(List<String> list, TipoFile tipo) {
		FileMap linea = new FileMap(list.get(0), tipo, Integer.valueOf(list.get(1)));
		return linea;
	}

	private static void writer() {
		try {
			List<TipoFile> tipiList = Arrays.asList(TipoFile.DOCUMENTS, TipoFile.IMAGE, TipoFile.VIDEO, TipoFile.OTHER);
			FileWriter myWriter = new FileWriter(
					"C:\\Users\\franc\\eclipse-workspace\\ProgettoEserciziIDM\\src\\main\\java\\esercizio1\\data.txt",
					false);
			for (TipoFile tipoFile : tipiList) {
				FileMap fileMassimo = new FileMap(null, null, 0);
				Integer sommaDim = 0;
				List<FileMap> listaFile = reader(tipoFile);
				for (FileMap file : listaFile) {
					sommaDim += file.getDimensione();
					if (file.getDimensione() > fileMassimo.getDimensione()) {
						fileMassimo = file;
					}
				}
				myWriter.write(tipoFile.getName() + " " + sommaDim + " " + fileMassimo.getName() + " "
						+ fileMassimo.getDimensione() + "\n");
			}

			myWriter.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static List<FileMap> reader(TipoFile tipo) {
		try {
			File myObj = new File(
					"C:\\Users\\franc\\eclipse-workspace\\ProgettoEserciziIDM\\src\\main\\java\\esercizio1\\filename.txt");
			Scanner myReader = new Scanner(myObj);
			List<FileMap> listaLinee = new ArrayList<FileMap>();
			while (myReader.hasNextLine()) {
				String data = myReader.nextLine();
				List<String> list = Arrays.asList(data.split(" "));
				String type = exporter(list.get(0));
				if (type.equals(tipo.getExtention().get(0)) || type.equals(tipo.getExtention().get(1))) {
					listaLinee.add(mapping(list, tipo));
				}else if (isOther(type) && tipo.equals(TipoFile.OTHER)) {
					listaLinee.add(mapping(list, TipoFile.OTHER));
				}

			}
			myReader.close();
			return listaLinee;
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
		return null;
	}

	private static String exporter(String s) {
		List<String> list = new ArrayList<>(Arrays.asList(s.split("")));
		boolean check = false;
		String tipo = "";
		for (String string : list) {
			if (check) {
				tipo += string;
			}

			if (string.equals(".")) {
				check = true;
			}
		}
		return tipo;
	}

	private static Boolean isOther(String tipo) {
		List<TipoFile> tipiList = Arrays.asList(TipoFile.DOCUMENTS, TipoFile.IMAGE, TipoFile.VIDEO, TipoFile.OTHER);
		for (TipoFile tipoFile : tipiList) {
			if (tipo.equals(tipoFile.getExtention().get(0)) || tipo.equals(tipoFile.getExtention().get(1))) return false;
		}
		return true;
	}

}
