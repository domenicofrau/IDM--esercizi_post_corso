package esercizio1;

public class FileMap {

	private String name;
	private TipoFile tipo;
	private Integer dimensione;

	public FileMap(String name, TipoFile tipo, Integer dimensione) {
		super();
		this.name = name;
		this.tipo = tipo;
		this.dimensione = dimensione;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public TipoFile getTipo() {
		return tipo;
	}

	public void setTipo(TipoFile tipo) {
		this.tipo = tipo;
	}

	public Integer getDimensione() {
		return dimensione;
	}

	public void setDimensione(Integer dimensione) {
		this.dimensione = dimensione;
	}

}
